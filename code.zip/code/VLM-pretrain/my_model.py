import torch
from torch import nn
import torch.nn.functional as F
import numpy as np
from backbones.image_encoder.ImageEncoder import ImageEncoder_Vit
from backbones.bert_model.TextEncoder import TextEncoder_Bert
from einops import rearrange
from utils.PDT import DisTrans, init_weights
import torch.distributions as dist



device = torch.device('cuda:0')

def sigmoid_mapping(x):
    return 1 / (1 + torch.exp(-x))


def Wasserstein2(mu1, sigma1, mu2, sigma2): # 2W距离，传入图片和文本的均值和标准差
    bs1 = mu1.shape[1]
    bs2 = mu2.shape[1]
    mu1 = torch.stack([mu1]*bs2, dim=1)
    sigma1 = torch.stack([sigma1]*bs2, dim=1)
    mu2 = torch.stack([mu2]*bs1, dim=1)
    sigma2 = torch.stack([sigma2]*bs1, dim=1)
    p1 = torch.sum(torch.pow(mu1 - mu2, 2), dim=-1)
    p2 = torch.sum(torch.pow(sigma1 - sigma2, 2), dim=-1)
    return p1+p2, p1


def Wasserstein2_global_intra_modal_loss(mu1, sigma1, mu2, sigma2, a, b, temp): # 2W距离，传入图片和文本的均值和标准差  [b, 128]
    bs1 = mu1.shape[0]  # b
    bs2 = mu2.shape[0]  # b
    mu1 = torch.stack([mu1]*bs2, dim=1)  # [b, b, 128]
    sigma1 = torch.stack([sigma1]*bs2, dim=1)  # [b, b, 128]
    mu2 = torch.stack([mu2]*bs1, dim=0)  # [b, b, 128]
    sigma2 = torch.stack([sigma2]*bs1, dim=0)  # [b, b, 128]
    p1 = torch.sum(torch.pow(mu1 - mu2, 2), dim=-1)  # [b, b]
    p2 = torch.sum(torch.pow(sigma1 - sigma2, 2), dim=-1)  # [b, b]
    W2_distance = p1+p2
    similarity = (-a * W2_distance + b) / temp
    labels = torch.arange(bs1).to(similarity.device)
    loss = (F.cross_entropy(similarity, labels) + F.cross_entropy(similarity.transpose(0, 1), labels)) / 2
    return loss  # [b, b]


def local_intra_modal_loss(l, m, temp, attention_mask=None):
    m = m.unsqueeze(1)
    N, n_locals, dim = l.size()
    l_n = l.reshape(-1, dim) # (N * n_locals) * d
    m_n = m.reshape(-1, dim) # N * d

    # Inner product for positive samples. Outer product for negative. We need to do it this way
    # for the multiclass loss. For the outer product, we want a N x N x n_locals x 1 tensor.
    u_p = torch.matmul(l, m.permute(0,2,1)).unsqueeze(2) / temp # N * n_locals * 1 * 1

    # if l comes from text, then attention_mask is not None
    if attention_mask is not None:
        temp_mask = attention_mask.unsqueeze(2).unsqueeze(3)
        u_p = (temp_mask * u_p) + (10000. * (1-temp_mask))

    u_n = torch.mm(m_n, l_n.t()) / temp
    u_n = u_n.reshape(N, 1, N, n_locals).permute(0, 2, 3, 1) # N x N x n_locals x 1

    # We need to mask the diagonal part of the negative tensor.
    mask = torch.eye(N)[:, :, None, None].to(l.device) # N*N*1*1
    n_mask = 1 - mask

    # Masking is done by shifting the diagonal before exp.
    u_n = (n_mask * u_n) - (10000. * (1 - n_mask))  # mask out "self" examples
    # if l comes from test, we mask out the padding tokens
    if attention_mask is not None:
        temp_mask = attention_mask.unsqueeze(0).unsqueeze(3).expand(N, -1, -1, -1)
        u_n = (temp_mask * u_n) - (10000. * (1-temp_mask))

    u_n = u_n.reshape(N, N * n_locals, 1).unsqueeze(dim=1).expand(-1, n_locals, -1, -1)

    # Since this is multiclass, we concat the positive along the class dimension before performing log softmax.
    pred_lgt = torch.cat([u_p, u_n], dim=2)
    pred_log = F.log_softmax(pred_lgt, dim=2)

    # The positive score is the first element of the log softmax.
    if attention_mask is not None:
        loss = (torch.sum(-pred_log[:, :, 0].squeeze(), dim=1) / torch.sum(attention_mask, dim=1)).mean()
    else:
        loss = -pred_log[:, :, 0].mean()

    return loss


class my_vlm(nn.Module):
    def __init__(self,
                 emb_dim: int = 128,
                 num_heads: int = 1,
                 device: str = 'cuda:0',
                 temperature: float = 0.07
                 ):
        super().__init__()
        self.device = torch.device(device)
        self.temperature = temperature
        self.momentum = 0.995

        self.img_encoder = ImageEncoder_Vit()
        self.img_aug_encoder = ImageEncoder_Vit()
        self.text_encoder = TextEncoder_Bert()
        self.text_aug_encoder = TextEncoder_Bert()

        self.img_gau_encoder = DisTrans(128, 8)
        self.img_gau_encoder_atten = DisTrans(128, 8)
        self.text_gau_encoder = DisTrans(128, 8)
        self.text_gau_encoder_atten = DisTrans(128, 8)
        self.img_aug_gau_encoder = DisTrans(128, 8)
        self.text_aug_gau_encoder = DisTrans(128, 8)
        self.img_gau_encoder.apply(init_weights)
        self.img_gau_encoder_atten.apply(init_weights)
        self.text_gau_encoder.apply(init_weights)
        self.text_gau_encoder_atten.apply(init_weights)
        self.img_aug_gau_encoder.apply(init_weights)
        self.text_aug_gau_encoder.apply(init_weights)

        self.patch_local_atten_layer = nn.MultiheadAttention(emb_dim, num_heads, batch_first=True)
        self.word_local_atten_layer = nn.MultiheadAttention(emb_dim, num_heads, batch_first=True)

        self.model_pairs = [[self.img_encoder, self.img_aug_encoder],
                            [self.text_encoder, self.text_aug_encoder],
                            ]
        self.copy_params()  # 切断 model_m 的梯度

    def forward(self, image, image_aug, texts):

        # Forward image encoder
        img_feat, patch_feat = self.img_encoder(image)
        patch_emb = self.img_encoder.local_embed(patch_feat)
        patch_emb = F.normalize(patch_emb, dim=-1)
        img_emb = self.img_encoder.global_embed(img_feat)
        img_emb = F.normalize(img_emb, dim=-1)

        # Forward text encoder
        report_feat, word_feat, word_attn_all, sents = self.text_encoder(texts, self.device)
        word_attn = word_attn_all[:, 1:].contiguous()
        word_emb = self.text_encoder.local_embed(word_feat)
        word_emb = F.normalize(word_emb, dim=-1)
        report_emb = self.text_encoder.global_embed(report_feat)
        report_emb = F.normalize(report_emb, dim=-1)

        bz = img_emb.size(0)
        labels = torch.arange(bz).type_as(report_emb).long()
        scores = img_emb.mm(report_emb.t())
        scores /= self.temperature
        scores1 = scores.transpose(0, 1)
        loss0 = F.cross_entropy(scores, labels)
        loss1 = F.cross_entropy(scores1, labels)
        loss_ori = (loss0 + loss1) / 2.0

        with torch.no_grad():
            self._momentum_update()
            img_aug_feat, patch_aug_feat = self.img_aug_encoder(image_aug)
            patch_aug_emb = self.img_aug_encoder.local_embed(patch_aug_feat)
            patch_aug_emb = F.normalize(patch_aug_emb, dim=-1)
            img_aug_emb = self.img_aug_encoder.global_embed(img_aug_feat)
            img_aug_emb = F.normalize(img_aug_emb, dim=-1)
            img_aug_emb_all = torch.cat([img_aug_emb.unsqueeze(1), patch_aug_emb], dim=1)

            report_aug_feat, word_aug_feat, word_aug_attn_all, sents_aug = self.text_aug_encoder(texts, self.device)
            word_aug_emb = self.text_aug_encoder.local_embed(word_aug_feat)
            word_aug_emb = F.normalize(word_aug_emb, dim=-1)
            report_aug_emb = self.text_aug_encoder.global_embed(report_aug_feat)
            report_aug_emb = F.normalize(report_aug_emb, dim=-1)
            text_aug_emb_all = torch.cat([report_aug_emb.unsqueeze(1), word_aug_emb], dim=1)

        # compute global cross-modal uncertainty loss
        #################################################################################################################################
        mask = torch.from_numpy(np.array(sents)[:, 1:] == "[PAD]").type_as(patch_emb).bool()
        atten_sim = torch.bmm(word_emb, patch_emb.permute(0, 2, 1))  # [2, 9, 196]
        atten_scores = F.softmax(atten_sim / self.temperature, dim=-1)
        word_atten_output = torch.bmm(atten_scores, patch_emb)  # [2, 9, 128]
        word_atten_output = F.normalize(word_atten_output, dim=-1)
        bz = image.size(0)
        with torch.no_grad():
            atten_weights = word_attn.detach()  # [2, 9]
            word_atten_weights = []
            for i in range(bz):
                atten_weight = atten_weights[i]
                nonzero = atten_weight.nonzero().squeeze()
                low = torch.quantile(atten_weight[nonzero], 0.1)
                high = torch.quantile(atten_weight[nonzero], 0.9)
                atten_weight[nonzero] = atten_weight[nonzero].clip(low, high)
                word_atten_weights.append(atten_weight.clone())
            word_atten_weights = torch.stack(word_atten_weights)  # [2, 9]
        word_atten_weights /= word_atten_weights.sum(dim=1, keepdims=True)  # [2, 9]
        word_sim = torch.bmm(word_emb, word_atten_output.permute(0, 2, 1)) / self.temperature  # [2, 9, 9]
        # -----------------------------------------------------提取文本分布表征--------------------------------------------------------------
        image_masks = torch.ones((patch_emb.size(0), patch_emb.size(1)), dtype=torch.long, device=self.device)
        extend_image_masks = self.text_encoder.model.get_extended_attention_mask(image_masks, image_masks.size(), self.device, is_decoder=False)
        text_masks = word_attn
        input_shape = text_masks.size()
        extend_text_masks = self.text_encoder.model.get_extended_attention_mask(text_masks, input_shape, self.device, is_decoder=False)
        text_mu, text_logsigma, _ = self.text_gau_encoder(word_emb, mask=extend_text_masks)
        text_mu_atten, text_logsigma_atten, _ = self.text_gau_encoder_atten(word_atten_output, mask=extend_text_masks)
        word_uncertainty, word_semantic = Wasserstein2(text_mu, text_logsigma, text_mu_atten, text_logsigma_atten)  # [2, 9, 9]
        word_uncertainty_1 = rearrange(word_uncertainty, "b n1 n2 -> (b n1) n2")  # [18, 9]
        word_uncertainty_2 = rearrange(word_uncertainty, "b n1 n2 -> (b n2) n1")  # [18, 9]
        word_semantic_1 = rearrange(word_semantic, "b n1 n2 -> (b n1) n2")  # [18, 9]
        word_semantic_2 = rearrange(word_semantic, "b n1 n2 -> (b n2) n1")  # [18, 9]
        word_constraint_1 = (word_uncertainty_1 / word_semantic_1)
        word_constraint_1 = sigmoid_mapping(word_constraint_1)
        word_constraint_2 = (word_uncertainty_2 / word_semantic_2)
        word_constraint_2 = sigmoid_mapping(word_constraint_2)
        # -----------------------------------------------------提取文本分布表征--------------------------------------------------------------
        word_num = word_sim.size(1)  # 9
        word_sim_1 = rearrange(word_sim, "b n1 n2 -> (b n1) n2")  # [18, 9]
        word_sim_1 = 1 - torch.mul((1 - word_sim_1), word_constraint_1)
        targets = torch.arange(word_num).type_as(word_emb).long().repeat(bz)  # [18]
        loss_word_1 = torch.sum(F.cross_entropy(word_sim_1, targets, reduction="none") * word_atten_weights.view(-1)) / bz
        word_sim_2 = rearrange(word_sim, "b n1 n2 -> (b n2) n1")
        word_sim_2 = 1 - torch.mul((1 - word_sim_2), word_constraint_2)
        loss_word_2 = torch.sum(F.cross_entropy(word_sim_2, targets, reduction="none") * word_atten_weights.view(-1)) / bz
        loss_word = (loss_word_1 + loss_word_2) / 2.

        atten_sim = torch.bmm(patch_emb, word_emb.permute(0, 2, 1))  # [2, 196, 9]
        patch_num = patch_emb.size(1)  # 196
        atten_sim[mask.unsqueeze(1).repeat(1, patch_num, 1)] = float("-inf")  # [2, 196, 9]
        atten_scores = F.softmax(atten_sim / self.temperature, dim=-1)  # [2, 196, 9]
        patch_atten_output = torch.bmm(atten_scores, word_emb)  # [2, 196, 128]
        with torch.no_grad():
            img_attn_map = self.img_encoder.model.blocks[-1].attn.attention_map.detach()
            atten_weights = img_attn_map[:, :, 0, 1:].mean(dim=1)
            patch_atten_weights = []
            for i in range(bz):
                atten_weight = atten_weights[i]
                atten_weight = atten_weight.clip(torch.quantile(atten_weight, 0.1), torch.quantile(atten_weight, 0.9))
                patch_atten_weights.append(atten_weight.clone())
            patch_atten_weights = torch.stack(patch_atten_weights)
        patch_atten_weights /= patch_atten_weights.sum(dim=1, keepdims=True)
        patch_sim = torch.bmm(patch_emb, patch_atten_output.permute(0, 2, 1)) / self.temperature
        #-----------------------------------------------------提取图像分布表征--------------------------------------------------------------
        img_mu, img_logsigma, _ = self.img_gau_encoder(patch_emb, mask=extend_image_masks)
        img_mu_atten, img_logsigma_atten, _ = self.text_gau_encoder_atten(patch_atten_output, mask=extend_image_masks)
        img_uncertainty, img_semantic = Wasserstein2(img_mu, img_logsigma, img_mu_atten, img_logsigma_atten)  # [2, 196, 196]
        img_uncertainty_1 = rearrange(img_uncertainty, "b n1 n2 -> (b n1) n2")  # [196*2, 196]
        img_uncertainty_2 = rearrange(img_uncertainty, "b n1 n2 -> (b n2) n1")  # [196*2, 196]
        img_semantic_1 = rearrange(img_semantic, "b n1 n2 -> (b n1) n2")  # [196*2, 196]
        img_semantic_2 = rearrange(img_semantic, "b n1 n2 -> (b n2) n1")  # [196*2, 196]
        img_constraint_1 = (img_uncertainty_1 / img_semantic_1)
        img_constraint_1 = sigmoid_mapping(img_constraint_1)
        img_constraint_2 = (img_uncertainty_2 / img_semantic_2)
        img_constraint_2 = sigmoid_mapping(img_constraint_2)
        # -----------------------------------------------------提取图像分布表征--------------------------------------------------------------
        patch_num = patch_sim.size(1)
        patch_sim_1 = rearrange(patch_sim, "b n1 n2 -> (b n1) n2")  # [392, 196]
        patch_sim_1 = 1 - torch.mul((1 - patch_sim_1), img_constraint_1)
        targets = torch.arange(patch_num).type_as(patch_emb).long().repeat(bz)
        loss_patch_1 = torch.sum(F.cross_entropy(patch_sim_1, targets, reduction="none") * patch_atten_weights.view(-1)) / bz
        patch_sim_2 = rearrange(patch_sim, "b n1 n2 -> (b n2) n1")
        patch_sim_2 = 1 - torch.mul((1 - patch_sim_2), img_constraint_2)
        loss_patch_2 = torch.sum(F.cross_entropy(patch_sim_2, targets, reduction="none") * patch_atten_weights.view(-1)) / bz
        loss_patch = (loss_patch_1 + loss_patch_2) / 2.
        loss_global = (loss_patch + loss_word) / 2.0
        #################################################################################################################################


        # compute local cross-modal uncertainty loss
        #################################################################################################################################
        l_patch_sim = patch_emb @ report_emb.t()  # [2, 196, 2]
        l_patch_weight = []
        for batch_idx in range(bz):
            weight_batch_idx = torch.var(torch.cat((l_patch_sim[batch_idx, :, :batch_idx], l_patch_sim[batch_idx, :, batch_idx:]), dim=1), dim=1)  # [196]
            weight_batch_idx = F.normalize(weight_batch_idx, dim=0)
            weight_batch_idx = 1 / weight_batch_idx
            weight_batch_idx = (weight_batch_idx - weight_batch_idx.min()) / (weight_batch_idx.max() - weight_batch_idx.min())
            l_patch_weight.append(weight_batch_idx)
        l_patch_weight = torch.stack(l_patch_weight)  # [2, 196]
        labels = torch.arange(bz).type_as(img_emb).long()
        loss_patch2report = 0
        for patch_idx in range(patch_emb.size(1)):
            sim_patch_idx = (patch_emb[:, patch_idx, :] @ report_emb.t()) / self.temperature  # [2, 2]
            loss_patch2report += F.cross_entropy(sim_patch_idx, labels) * l_patch_weight[:, patch_idx].view(-1)
        loss_patch2report = torch.sum(loss_patch2report / patch_emb.size(1)) / bz

        l_word_sim = word_emb @ img_emb.t()  # [2, 9, 2]
        l_word_weight = []
        for batch_idx in range(bz):
            weight_batch_idx = torch.var(torch.cat((l_word_sim[batch_idx, :, :batch_idx], l_word_sim[batch_idx, :, batch_idx:]), dim=1), dim=1)  # [9]
            weight_batch_idx = F.normalize(weight_batch_idx, dim=0)
            weight_batch_idx = 1 / weight_batch_idx
            weight_batch_idx = (weight_batch_idx - weight_batch_idx.min()) / (weight_batch_idx.max() - weight_batch_idx.min())
            l_word_weight.append(weight_batch_idx)
        l_word_weight = torch.stack(l_word_weight)  # [2, 9]
        loss_word2img = 0
        for word_idx in range(word_emb.size(1)):
            sim_word_idx = (word_emb[:, word_idx, :] @ img_emb.t()) / self.temperature  # [2, 2]
            loss_word2img += F.cross_entropy(sim_word_idx, labels) * l_word_weight[:, word_idx].view(-1)
        loss_word2img = torch.sum(loss_word2img / word_emb.size(1)) / bz
        loss_local = loss_patch2report + loss_word2img
        #################################################################################################################################


        # compute intra-modal loss
        #################################################################################################################################
        # -----------------------------------------------------提取增强文本分布表征--------------------------------------------------------------
        image_aug_masks = torch.ones((img_aug_emb_all.size(0), img_aug_emb_all.size(1)), dtype=torch.long, device=self.device)
        with torch.no_grad():
            extend_image_masks_aug = self.text_aug_encoder.model.get_extended_attention_mask(image_aug_masks, image_aug_masks.size(), self.device, is_decoder=False)
        text_aug_masks = word_aug_attn_all
        input_shape_aug = text_aug_masks.size()
        with torch.no_grad():
            extend_text_masks_aug = self.text_aug_encoder.model.get_extended_attention_mask(text_aug_masks, input_shape_aug, self.device, is_decoder=False)
        text_aug_mu, text_aug_logsigma, _ = self.text_gau_encoder(text_aug_emb_all, mask=extend_text_masks_aug)  # [2, 10, 128]
        img_aug_mu, img_aug_logsigma, _ = self.img_aug_gau_encoder(img_aug_emb_all, mask=extend_image_masks_aug)  # [2, 197, 128]

        intra_global_loss = Wasserstein2_global_intra_modal_loss(img_aug_mu[:, 0, :], img_aug_logsigma[:, 0, :], text_aug_mu[:, 0, :], text_aug_logsigma[:, 0, :], a=1/200, b=4.0, temp= self.temperature)
        standard_normal = dist.Normal(0, 1)
        sample_value = standard_normal.sample()
        img_distribution = img_aug_mu + sample_value * img_aug_logsigma
        text_distribution = text_aug_mu + sample_value * text_aug_logsigma
        intra_local_loss_img = local_intra_modal_loss(img_distribution[:, 1:, :], img_distribution[:, 0, :], temp=self.temperature)
        intra_local_loss_text = local_intra_modal_loss(text_distribution[:, 1:, :], text_distribution[:, 0, :], temp=self.temperature)
        loss_intra = (intra_global_loss + ((intra_local_loss_img + intra_local_loss_text) / 2.0)) / 2.0

        return loss_ori, loss_global, loss_local, loss_intra


    @torch.no_grad()
    def copy_params(self):
        for model_pair in self.model_pairs:
            for param, param_m in zip(model_pair[0].parameters(), model_pair[1].parameters()):
                param_m.data.copy_(param.data)  # initialize
                param_m.requires_grad = False  # not update by gradient

    @torch.no_grad()
    def _momentum_update(self):
        for model_pair in self.model_pairs:
            for param, param_m in zip(model_pair[0].parameters(), model_pair[1].parameters()):
                param_m.data = param_m.data * self.momentum + param.data * (1. - self.momentum)



model = my_vlm().to(device)
img = torch.rand(4, 3, 224, 224).to(device)
img_aug = torch.rand(4, 3, 224, 224).to(device)
text = ['Bilateral pulmonary infection, two infected areas, middle lower left lung and upper middle lower right lung.', 'my dog', 'my paper', 'vision language model']
loss_ori, loss_global, loss_local, loss_intra = model(img, img_aug, text)
print(loss_ori, loss_global, loss_local, loss_intra)
            


























